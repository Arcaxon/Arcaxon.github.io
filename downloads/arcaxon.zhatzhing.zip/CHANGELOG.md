## Initial Release
1.0 Release - added zhat zhing (Shiny Junk)