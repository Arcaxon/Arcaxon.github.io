This is a mod that adds Zhat Zhing from Valsalia's Out of Placers Comic to the metal detector pool, with potential to add more to it!
Version: 1.0.0
Authors: Arcaxon

Find my other webfishing mods at: https://Arcaxon.com/webfishing/

Zhat Zhing, yinglets, & Out of Placers by Valsalia: https://Valsalia.com


This mod was made with the help of Hatchery 1.1.0 with modifications to the files it generated, seriously great template creator!
https://github.com/coolbot100s/Hatchery