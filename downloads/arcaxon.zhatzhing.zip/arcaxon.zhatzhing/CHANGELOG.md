## Initial Release

### 1.1.0 - Added 6 Titles

### 1.0.0 Release - added zhat zhing (Shiny Junk)